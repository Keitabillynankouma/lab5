import _ from 'lodash';

// BEGIN
import { sum } from 'lodash';

export default function average(...args) {
    if (args.length === 0) {
        return null;
    }
    const total = sum(args);
    return total / args.length;
}

// END