import get from 'lodash/get.js';

const freeEmailDomains = [
  'gmail.com',
  'yandex.ru',
  'hotmail.com',
  'yahoo.com',
];

// BEGIN

function getFreeDomainsCount(emails) {
    return emails.reduce((acc, email) => {
        const domain = email.split('@')[1];
        const freeDomain = _.get(freeEmailDomains.find(freeDomain => domain.includes(freeDomain)), null);
        if (freeDomain) {
            acc[freeDomain] = (acc[freeDomain] || 0) + 1;
        }
        return acc;
    }, {});
}

export default getFreeDomainsCount;

// END