// BEGIN
export default function convert(...dates) {
    if (dates.length === 0) {
        return [];
    }
    
    const result = dates.map(date => {
        const [year, month, day] = date;
        const dateString = new Date(year, month - 1, day).toDateString();
        return dateString;
    });
    
    return result;
}

// END