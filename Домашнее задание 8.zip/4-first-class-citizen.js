const run = (text) => {
    // BEGIN

    // END
  
    return takeLast(text, 4);
  };
  
export default run;