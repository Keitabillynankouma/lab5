// BEGIN
const sayPrimeOrNot = (num) => {
    if (isPrime(num)) {
      console.log('yes');
    } else {
      console.log('no');
    }
  };
  
  export default sayPrimeOrNot;

// END